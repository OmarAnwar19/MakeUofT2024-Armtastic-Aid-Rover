def forward():
    print("forward")

def backward():
    print("backward")

def left():
    print("left")

def right():
    print("right")

def stop():
    print("stop")